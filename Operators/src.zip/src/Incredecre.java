//Write a Java program where a variable is incremented by 5 using ++ and then decremented by 3 using --.

public class Incredecre {
public static void main(String[] args) {
	int a=5;
	a++;
	System.out.println(a);
	a--;
	System.out.println(a);
}
}

//Write a program to calculate the square and cube of a given number.

public class Que3 {
public static void main(String[] args) {
	int a=4;
	int square=a*a;
	int cube=a*a*a;
	System.out.println("Square of given num= "+square);
	System.out.println("Cube of given number ="+cube);
}
}

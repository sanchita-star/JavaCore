//Write a Java program to find the largest of two numbers using relational operators.
public class Que8 {
public static void main(String[] args) {
	int num1=5;
	int num2=6;
	if(num1>num2) {
		System.out.println("num1 is largest");
	}
	else
	{
		System.out.println("num2 is largest");
	}
	//Write a Java program to check whether a given number is greater than 100 or not using relational operators.
if(num1>100)
{
	System.out.println("greater than 100");
}
else {
	System.out.println("not greater than 100");
}
}
}

//Write a Java program to find the area and perimeter of a rectangle using arithmetic operators.

public class Que4 {
public static void main(String[] args) {
	int length=34;
	int breadth=45;
	int area=length*breadth;
	int perimeter=2*(length+breadth);
	System.out.println("Area="+area);
	System.out.println("Perimeter="+perimeter);
}
}

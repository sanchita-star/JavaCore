//Write a program to find the remainder when one number is divided by another using the modulus (%) operator.
public class Que1 {
	public static void main(String[] args) {
		
	
int num1=45;
int num2=5;
int ans=num1%num2;
System.out.println(ans);
	}
}

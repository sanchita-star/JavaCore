//Write a Java program to compare two numbers using ==, !=, >, <, >=, and <= and display the results.

public class Que6 {
public static void main(String[] args) {
	int num1=34;
	int num2=45;
	System.out.println(num1==num2);
	System.out.println(num1!=num2);
	System.out.println(num1>num2);
	System.out.println(num1<num2);
	System.out.println(num1>=num2);
	System.out.println(num1<=num2);
}
}

//Write a Java program to check whether a person is eligible to vote (age should be 18 or above).
public class Que7 {
public static void main(String[] args) {
	int age=20;
	if(age>=18) {
		System.out.println("Person is eligible for voting");
	}
	else
	{
		System.out.println("not eligible");
	}
}
}
